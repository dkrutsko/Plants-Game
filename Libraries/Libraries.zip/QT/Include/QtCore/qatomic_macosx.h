#include "../../src/corelib/arch/qatomic_macosx.h"
