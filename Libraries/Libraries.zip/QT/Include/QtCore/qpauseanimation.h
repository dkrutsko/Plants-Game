#include "../../src/corelib/animation/qpauseanimation.h"
