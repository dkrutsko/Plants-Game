#include "../../src/corelib/arch/qatomic_x86_64.h"
