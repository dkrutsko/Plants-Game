#include "../../src/corelib/kernel/qfunctions_wince.h"
