#include "../../src/corelib/arch/qatomic_symbian.h"
