#include "../../src/corelib/arch/qatomic_mips.h"
