#include "../../src/corelib/kernel/qobject.h"
