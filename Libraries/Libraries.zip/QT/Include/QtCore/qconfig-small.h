#include "../../src/corelib/global/qconfig-small.h"
