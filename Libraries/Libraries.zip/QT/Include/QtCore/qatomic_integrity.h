#include "../../src/corelib/arch/qatomic_integrity.h"
