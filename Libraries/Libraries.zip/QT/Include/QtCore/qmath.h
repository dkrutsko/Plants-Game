#include "../../src/corelib/kernel/qmath.h"
