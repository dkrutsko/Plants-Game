#include "../../src/corelib/kernel/qsharedmemory.h"
