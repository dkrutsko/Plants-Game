#include "../../src/corelib/concurrent/qtconcurrentmapkernel.h"
