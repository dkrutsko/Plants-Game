#include "../../src/corelib/arch/qatomic_bfin.h"
