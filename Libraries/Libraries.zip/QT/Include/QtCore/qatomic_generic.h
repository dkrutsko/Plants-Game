#include "../../src/corelib/arch/qatomic_generic.h"
