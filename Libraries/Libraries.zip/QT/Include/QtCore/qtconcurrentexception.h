#include "../../src/corelib/concurrent/qtconcurrentexception.h"
