#include "../../src/corelib/arch/qatomic_windows.h"
