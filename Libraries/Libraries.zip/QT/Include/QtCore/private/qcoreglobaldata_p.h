#include "../../../src/corelib/kernel/qcoreglobaldata_p.h"
