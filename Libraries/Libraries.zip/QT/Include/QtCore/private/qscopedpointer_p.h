#include "../../../src/corelib/tools/qscopedpointer_p.h"
