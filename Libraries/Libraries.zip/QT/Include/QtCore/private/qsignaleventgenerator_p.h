#include "../../../src/corelib/statemachine/qsignaleventgenerator_p.h"
