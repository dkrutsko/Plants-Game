#include "../../../src/corelib/codecs/qtextcodec_p.h"
