#include "../../../src/corelib/io/qiodevice_p.h"
