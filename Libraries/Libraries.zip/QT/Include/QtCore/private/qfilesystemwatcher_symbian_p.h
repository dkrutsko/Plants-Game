#include "../../../src/corelib/io/qfilesystemwatcher_symbian_p.h"
