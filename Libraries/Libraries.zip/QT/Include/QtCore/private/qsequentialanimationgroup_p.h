#include "../../../src/corelib/animation/qsequentialanimationgroup_p.h"
