#include "../../../src/corelib/kernel/qsharedmemory_p.h"
