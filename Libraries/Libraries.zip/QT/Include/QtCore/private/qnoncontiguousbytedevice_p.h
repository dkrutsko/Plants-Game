#include "../../../src/corelib/io/qnoncontiguousbytedevice_p.h"
