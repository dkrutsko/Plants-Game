#include "../../src/corelib/tools/qeasingcurve.h"
