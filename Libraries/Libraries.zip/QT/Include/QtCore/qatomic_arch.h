#include "../../src/corelib/arch/qatomic_arch.h"
